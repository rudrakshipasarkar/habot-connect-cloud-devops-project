# Assumptions and explicit design decisions

**Candidate:** Rudrakshi Pasarkar  
**Contact:** rudrakshipasarkar@gmail.com

The supplied brief requests exact validation but does not include a source JSON payload, field list, retention policy, identities, or numeric constraints. This solution makes those decisions explicit so a reviewer can change them without hidden behavior.

1. Learners are aged 3 through 21 inclusive.
2. Names contain 2 through 80 Latin letters plus spaces, apostrophes, periods, or hyphens.
3. Guardian email length cannot exceed 254 characters.
4. Guardian consent must be exactly `true`; missing or false fails closed.
5. Region is either `UAE` or `OTHER`. UAE analysts can query only UAE rows.
6. Support type must be one controlled value when support is required and must be null otherwise.
7. Notes are optional and limited to 500 characters.
8. Event IDs are UUIDs and provide an idempotency key.
9. Raw records have a 30-day retention policy and lifecycle deletion after 90 days.
10. Customer-managed encryption keys rotate every 90 days and cannot be destroyed through Terraform.
11. The pipeline quarantines a redacted finding report, not source that may contain a secret.

The production owner should confirm data residency, retention, lawful basis, support taxonomy, and age limits before deployment.

