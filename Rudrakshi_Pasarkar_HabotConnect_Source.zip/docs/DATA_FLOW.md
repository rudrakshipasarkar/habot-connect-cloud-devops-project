# Validated data flow and failure handling

**Candidate:** Rudrakshi Pasarkar  
**Contact:** rudrakshipasarkar@gmail.com

1. React submits HTTPS JSON to Django REST Framework.
2. `StudentOnboardingSerializer` rejects unknown choices, missing consent, inconsistent support fields, and values outside explicit limits.
3. The DCYN library records six deterministic Yes/No decisions. Any No prevents publication.
4. `publisher.to_pubsub_bytes` emits only the eleven fields in the BigQuery schema. Extra application fields cannot leak into analytics.
5. Pub/Sub retains messages for seven days and retries delivery. Five failed attempts send the message to an encrypted dead-letter topic.
6. The BigQuery subscription uses the table schema and does not drop unknown fields. Schema drift fails instead of silently discarding data.
7. The table partitions on `submitted_at` and clusters on `learner_region` and `support_required`.
8. Row-level access restricts the analyst group and analytics service account to UAE records.

## Schema-change procedure

- Add a new schema version rather than changing the meaning of an existing field.
- Update the serializer, JSON Schema, BigQuery schema, mapping tuple, tests, and presentation together.
- Deploy additive nullable fields before publishers begin sending them.
- Route incompatible payloads to the dead-letter topic and alert the owner.

