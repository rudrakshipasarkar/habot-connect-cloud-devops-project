"""Student onboarding validation package."""
