# Candidate: Rudrakshi Pasarkar | Contact: rudrakshipasarkar@gmail.com
import json
import unittest
from application.onboarding.publisher import BIGQUERY_FIELDS, to_pubsub_bytes


class PublisherTests(unittest.TestCase):
    def test_mapping_has_exact_bigquery_fields(self):
        payload = {field: "value" for field in BIGQUERY_FIELDS}
        event = json.loads(to_pubsub_bytes(payload))
        self.assertEqual(set(BIGQUERY_FIELDS), set(event))

    def test_missing_required_field_is_rejected(self):
        with self.assertRaises(ValueError):
            to_pubsub_bytes({"schema_version": "1.0"})


if __name__ == "__main__":
    unittest.main()
