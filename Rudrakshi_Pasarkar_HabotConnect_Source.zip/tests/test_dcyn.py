# Candidate: Rudrakshi Pasarkar | Contact: rudrakshipasarkar@gmail.com
from datetime import date
import unittest
from application.onboarding.dcyn import BinaryChoice, accepted, evaluate


def valid_payload():
    year = date.today().year - 10
    return {
        "student_full_name": "Amina Rahman",
        "date_of_birth": f"{year}-05-18",
        "guardian_email": "guardian@example.com",
        "learner_region": "UAE",
        "guardian_consent": True,
        "support_required": True,
        "support_type": "COMMUNICATION",
    }


class DcynTests(unittest.TestCase):
    def test_valid_payload_returns_only_yes(self):
        decisions = evaluate(valid_payload())
        self.assertTrue(accepted(valid_payload()))
        self.assertEqual(6, len(decisions))
        self.assertTrue(all(item.answer is BinaryChoice.YES for item in decisions))

    def test_missing_consent_fails_closed(self):
        payload = valid_payload()
        payload["guardian_consent"] = False
        self.assertFalse(accepted(payload))
        self.assertIn(
            "D005",
            [item.code for item in evaluate(payload) if item.answer is BinaryChoice.NO],
        )

    def test_support_type_cannot_exist_without_requirement(self):
        payload = valid_payload()
        payload["support_required"] = False
        self.assertFalse(accepted(payload))
        self.assertIn(
            "D006",
            [item.code for item in evaluate(payload) if item.answer is BinaryChoice.NO],
        )

    def test_unknown_region_fails_closed(self):
        payload = valid_payload()
        payload["learner_region"] = "UNKNOWN"
        self.assertFalse(accepted(payload))


if __name__ == "__main__":
    unittest.main()
