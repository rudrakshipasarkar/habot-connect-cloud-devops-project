# Candidate: Rudrakshi Pasarkar | Contact: rudrakshipasarkar@gmail.com
from datetime import date, datetime, timezone
import unittest
import uuid

from django.conf import settings

if not settings.configured:
    settings.configure(
        USE_TZ=True,
        TIME_ZONE="UTC",
        REST_FRAMEWORK={},
    )

from application.onboarding.serializers import StudentOnboardingSerializer


def valid_payload():
    return {
        "schema_version": "1.0",
        "event_id": str(uuid.uuid4()),
        "submitted_at": datetime.now(timezone.utc).isoformat(),
        "student_full_name": "Amina Rahman",
        "date_of_birth": date(date.today().year - 10, 5, 18).isoformat(),
        "guardian_email": "guardian@example.com",
        "learner_region": "UAE",
        "guardian_consent": True,
        "support_required": True,
        "support_type": "COMMUNICATION",
        "notes": "Prefers visual instructions.",
    }


class SerializerTests(unittest.TestCase):
    def test_valid_payload_has_six_yes_decisions(self):
        serializer = StudentOnboardingSerializer(data=valid_payload())
        self.assertTrue(serializer.is_valid(), serializer.errors)
        self.assertEqual(6, len(serializer.validated_data["dcyn_decisions"]))
        self.assertEqual(
            {"YES"}, set(serializer.validated_data["dcyn_decisions"].values())
        )

    def test_unknown_field_is_rejected(self):
        payload = valid_payload()
        payload["untrusted_extra"] = "must not reach analytics"
        serializer = StudentOnboardingSerializer(data=payload)
        self.assertFalse(serializer.is_valid())
        self.assertIn("unknown_fields", serializer.errors)

    def test_consent_false_is_rejected(self):
        payload = valid_payload()
        payload["guardian_consent"] = False
        serializer = StudentOnboardingSerializer(data=payload)
        self.assertFalse(serializer.is_valid())
        self.assertIn("guardian_consent", serializer.errors)

    def test_support_type_is_required_conditionally(self):
        payload = valid_payload()
        payload.pop("support_type")
        serializer = StudentOnboardingSerializer(data=payload)
        self.assertFalse(serializer.is_valid())
        self.assertIn("support_type", serializer.errors)


if __name__ == "__main__":
    unittest.main()
