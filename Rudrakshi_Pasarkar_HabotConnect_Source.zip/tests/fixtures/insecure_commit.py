# Deliberately invalid fixture used only by the fail-closed demonstration test.
API_KEY = "FAKE_EXAMPLE_VALUE_DO_NOT_USE"
