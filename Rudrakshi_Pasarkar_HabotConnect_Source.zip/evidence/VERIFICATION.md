# Verification record

**Candidate:** Rudrakshi Pasarkar  
**Contact:** rudrakshipasarkar@gmail.com  
**Executed:** 11 September 2026

| Check | Result |
|---|---|
| Ruff formatting | Passed |
| Ruff lint | Passed |
| Python compilation | Passed |
| Django REST Framework and DCYN tests | 10 passed |
| Bandit source scan | Passed |
| Pinned dependency vulnerability audit | No known vulnerabilities found |
| JSON and workflow YAML parsing | Passed |
| Normal secret gate | Passed |
| Controlled insecure fixture | Failed closed with exit code 1; value redacted |
| Terraform formatting and HCL parsing | Passed |
| Presentation package integrity | Passed, 12 slides |
| Presentation layout validation | Passed with no findings |

`terraform init` could not finish because the local network repeatedly interrupted the official Google provider download. Therefore provider-level resource schema validation and a live Google Cloud plan were not claimed. The GitHub Actions gate runs `terraform init` and `terraform validate` in a clean runner before deployment eligibility.

A live `terraform apply` was intentionally not executed because no Google Cloud project, billing configuration, approved analyst group, or deployment identity was supplied.

