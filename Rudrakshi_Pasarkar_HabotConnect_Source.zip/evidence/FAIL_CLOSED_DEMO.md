# Fail-closed demonstration

**Candidate:** Rudrakshi Pasarkar  
**Contact:** rudrakshipasarkar@gmail.com

`tests/fixtures/insecure_commit.py` contains a deliberately fake credential-shaped assignment. It never represents a real secret.

```text
python scripts/run_security_gate.py --scan-root . --report build/gate-report.json
FAIL-CLOSED: 1 potential secret finding(s); values redacted. Build quarantined.
exit code: 1
```

Normal pipeline behavior excludes the controlled fixture:

```text
python scripts/run_security_gate.py --scan-root . --report build/gate-report.json --allow-test-fixtures
PASS: no hardcoded secret patterns detected.
exit code: 0
```

The deployment job declares `needs: gate`, so it cannot run after any gate step fails. The failure artifact contains only rule name, relative path, and line number.

