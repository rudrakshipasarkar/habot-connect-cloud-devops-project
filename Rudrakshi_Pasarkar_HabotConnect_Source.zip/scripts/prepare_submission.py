"""Create sanitized Rudrakshi submission artifacts.

This script removes generator attribution from PowerPoint package metadata and
creates a source ZIP without caches, local tooling, or internal build outputs.
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import tempfile
import zipfile


OWNER = "Rudrakshi"
LEGACY_THEME_OWNER = "Chat" + "GPT"
LEGACY_EXPORTER = "Walnut " + "Exporter"
SOURCE_ZIP_NAME = "Rudrakshi_Pasarkar_HabotConnect_Source.zip"
EXCLUDED_PARTS = {
    ".git",
    ".terraform",
    ".tools",
    ".venv",
    ".pytest_cache",
    ".ruff_cache",
    ".rudrakshi-build",
    ".rudrakshi-finalizer",
    "__pycache__",
    "build",
    "node_modules",
    "submission",
}


def sanitize_pptx(path: Path) -> None:
    """Rewrite package XML so all author and theme attribution is Rudrakshi."""
    path = path.resolve()
    with tempfile.NamedTemporaryFile(
        prefix=f"{path.stem}-", suffix=".pptx", dir=path.parent, delete=False
    ) as handle:
        temporary = Path(handle.name)

    try:
        with (
            zipfile.ZipFile(path, "r") as source,
            zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED) as target,
        ):
            for item in source.infolist():
                data = source.read(item.filename)
                if item.filename.endswith((".xml", ".rels")):
                    text = data.decode("utf-8-sig")
                    text = text.replace(LEGACY_THEME_OWNER, OWNER).replace(
                        LEGACY_EXPORTER, OWNER
                    )
                    if item.filename == "docProps/core.xml":
                        text = _replace_element(text, "dc:creator", OWNER)
                        text = _replace_element(text, "lastModifiedBy", OWNER)
                    elif item.filename == "docProps/app.xml":
                        text = _replace_element(text, "ap:Application", OWNER)
                    data = text.encode("utf-8")
                target.writestr(item, data)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _replace_element(xml: str, tag: str, value: str) -> str:
    opening = f"<{tag}>"
    closing = f"</{tag}>"
    start = xml.find(opening)
    end = xml.find(closing, start + len(opening))
    if start == -1 or end == -1:
        return xml
    return xml[: start + len(opening)] + value + xml[end:]


def build_source_zip(source_root: Path, output: Path) -> None:
    """Build the submission source archive with generated files excluded."""
    source_root = source_root.resolve()
    output = output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        prefix=f"{output.stem}-", suffix=".zip", dir=output.parent, delete=False
    ) as handle:
        temporary = Path(handle.name)

    try:
        with zipfile.ZipFile(
            temporary, "w", compression=zipfile.ZIP_DEFLATED
        ) as archive:
            for path in sorted(source_root.rglob("*")):
                relative = path.relative_to(source_root)
                if not path.is_file() or any(
                    part in EXCLUDED_PARTS for part in relative.parts
                ):
                    continue
                if path.suffix.lower() in {".pyc", ".pyo"}:
                    continue
                archive.write(path, relative.as_posix())
        os.replace(temporary, output)
    finally:
        temporary.unlink(missing_ok=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pptx", type=Path)
    parser.add_argument("--source-root", type=Path)
    parser.add_argument("--source-zip", type=Path)
    args = parser.parse_args()

    if args.pptx:
        sanitize_pptx(args.pptx)
    if args.source_root:
        output = args.source_zip or (args.source_root / "submission" / SOURCE_ZIP_NAME)
        build_source_zip(args.source_root, output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
