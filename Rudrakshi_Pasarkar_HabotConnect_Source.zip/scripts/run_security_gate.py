"""Fail-closed local gate with redacted reporting.

Candidate: Rudrakshi Pasarkar | Contact: rudrakshipasarkar@gmail.com
"""

from __future__ import annotations
import argparse
import json
from pathlib import Path
import re
import sys

SECRET_RULES = {
    "google-api-key": re.compile(r"AIza[0-9A-Za-z_-]{35}"),
    "private-key": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    "generic-assignment": re.compile(
        r"(?i)(?:api[_-]?key|secret|token|password)\s*[:=]\s*['\"][^'\"]{12,}['\"]"
    ),
}
TEXT_SUFFIXES = {
    ".py",
    ".tf",
    ".tfvars",
    ".yml",
    ".yaml",
    ".json",
    ".js",
    ".jsx",
    ".ts",
    ".tsx",
    ".md",
}
EXCLUDED_PARTS = {
    ".git",
    ".terraform",
    ".venv",
    "node_modules",
    "build",
    ".rudrakshi-build",
    ".rudrakshi-finalizer",
}


def scan(root: Path) -> list[dict[str, object]]:
    findings = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in TEXT_SUFFIXES:
            continue
        relative = path.relative_to(root)
        if any(part in EXCLUDED_PARTS for part in relative.parts):
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        for line_number, line in enumerate(text.splitlines(), 1):
            for rule_name, pattern in SECRET_RULES.items():
                if pattern.search(line):
                    findings.append(
                        {
                            "rule": rule_name,
                            "file": relative.as_posix(),
                            "line": line_number,
                        }
                    )
    return findings


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--scan-root", type=Path, default=Path("."))
    parser.add_argument("--report", type=Path, default=Path("build/gate-report.json"))
    parser.add_argument("--allow-test-fixtures", action="store_true")
    args = parser.parse_args()
    findings = scan(args.scan_root.resolve())
    if args.allow_test_fixtures:
        findings = [
            item
            for item in findings
            if not str(item["file"]).startswith("tests/fixtures/")
        ]
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(
        json.dumps(
            {"status": "FAIL" if findings else "PASS", "findings": findings}, indent=2
        ),
        encoding="utf-8",
    )
    if findings:
        print(
            f"FAIL-CLOSED: {len(findings)} potential secret finding(s); values redacted. Build quarantined."
        )
        return 1
    print("PASS: no hardcoded secret patterns detected.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
